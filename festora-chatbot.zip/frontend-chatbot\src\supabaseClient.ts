import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = 'https://awdoignuguvsktagucdo.supabase.co'
// Full anon key from the Festora Supabase project
// Replace this with the actual anon key from Supabase Dashboard → Project Settings → API
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY ?? ''

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF3ZG9pZ251Z3V2c2t0YWd1Y2RvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDMwMzcyMDAsImV4cCI6MjAxODYxMzIwMH0.placeholder_key')
